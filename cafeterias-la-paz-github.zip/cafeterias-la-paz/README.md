# Cafeterías de La Paz

Tres propuestas web independientes para Kibou, Bodega y Le Tasse, La Paz, Baja California Sur.

| Sitio | Archivo principal |
| --- | --- |
| Kibou | [kibou/index.html](kibou/index.html) |
| Bodega | [bodega/index.html](bodega/index.html) |
| Le Tasse | [le-tasse/index.html](le-tasse/index.html) |

## Vista local

Son sitios estáticos con HTML, CSS y JavaScript. No requieren compilación.

Desde esta carpeta ejecuta `python3 -m http.server 8000` y abre http://localhost:8000.

Cada carpeta puede publicarse por separado en un alojamiento estático. Mantén juntos sus archivos y la carpeta assets.

## Contenido y recursos

Propuestas de diseño; no representan una afiliación oficial con los establecimientos. La información proviene de sus perfiles públicos y las fuentes indicadas en los sitios y archivos LEEME. Horarios, cartas y precios pueden cambiar. Las fotografías y marcas corresponden a sus respectivos titulares; su inclusión no concede derechos adicionales de reutilización. Kibou incluye recursos visuales generados, documentados en su carpeta assets.
